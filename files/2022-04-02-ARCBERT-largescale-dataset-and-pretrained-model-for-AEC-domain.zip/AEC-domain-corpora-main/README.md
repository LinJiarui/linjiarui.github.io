# AEC-domain-corpora
The code and dataset for the paper "Pretrained Domain-Specific Language Model for General Information Retrieval Tasks in the AEC Domain"
