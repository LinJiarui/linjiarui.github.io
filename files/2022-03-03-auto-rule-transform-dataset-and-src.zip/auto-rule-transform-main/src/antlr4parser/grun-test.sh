# grun RuleCheckTree rctree -tokens -gui -tree
cat input.log -First 1 | grun RuleCheckTree rctree -tokens -gui -tree
