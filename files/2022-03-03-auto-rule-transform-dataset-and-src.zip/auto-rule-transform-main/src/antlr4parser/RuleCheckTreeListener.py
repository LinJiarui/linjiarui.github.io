# Generated from RuleCheckTree.g4 by ANTLR 4.9.3
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .RuleCheckTreeParser import RuleCheckTreeParser
else:
    from RuleCheckTreeParser import RuleCheckTreeParser

# This class defines a complete listener for a parse tree produced by RuleCheckTreeParser.
class RuleCheckTreeListener(ParseTreeListener):

    # Enter a parse tree produced by RuleCheckTreeParser#rctree.
    def enterRctree(self, ctx:RuleCheckTreeParser.RctreeContext):
        pass

    # Exit a parse tree produced by RuleCheckTreeParser#rctree.
    def exitRctree(self, ctx:RuleCheckTreeParser.RctreeContext):
        pass


    # Enter a parse tree produced by RuleCheckTreeParser#prs.
    def enterPrs(self, ctx:RuleCheckTreeParser.PrsContext):
        pass

    # Exit a parse tree produced by RuleCheckTreeParser#prs.
    def exitPrs(self, ctx:RuleCheckTreeParser.PrsContext):
        pass


    # Enter a parse tree produced by RuleCheckTreeParser#pr.
    def enterPr(self, ctx:RuleCheckTreeParser.PrContext):
        pass

    # Exit a parse tree produced by RuleCheckTreeParser#pr.
    def exitPr(self, ctx:RuleCheckTreeParser.PrContext):
        pass


    # Enter a parse tree produced by RuleCheckTreeParser#req.
    def enterReq(self, ctx:RuleCheckTreeParser.ReqContext):
        pass

    # Exit a parse tree produced by RuleCheckTreeParser#req.
    def exitReq(self, ctx:RuleCheckTreeParser.ReqContext):
        pass



del RuleCheckTreeParser